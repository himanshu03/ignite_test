var GenericFlow = require('./generic_flow_controller.js');

describe('Send Order Creation', function() {
	
	var ptro;
	var params = browser.params;    		
	var genericFlow = new GenericFlow();  	
	var http = require('http');
	browser.get('http://qaasruiweb.va.neustar.com/oms/view/login');
	browser.driver.manage().window().maximize();	
	//console.log(params.url.baseUrl+'login');
	
	beforeEach(function(){
		genericFlow.flow("login_flow", "login");
	});
		
	 afterEach(function(){
		genericFlow.flow("logout_flow", "logout");
		
	}); 
	

	 it('Test create order request UNI-EU', function(){	
		genericFlow.flow("create_order_flow", "unieu");	       
	},15000000); 

/*	
	it('Test create order request UNI-EU-EVC', function(){		
		genericFlow.flow("create_order_flow", "unieuevc");	       
		},15000000); 

	it('Test create order request UNI-POP', function(){	
		genericFlow.flow("create_order_flow", "uninnipop");	       
	},15000000); 


it('Test create order request UNI-NNI-POP-EVC', function(){	
		genericFlow.flow("create_order_flow", "uninnipopevc");	       
	},15000000);

	
	it('Test create order request EVC Standalone', function(){	
		genericFlow.flow("create_order_flow", "evcStandalone");	       
	},15000000); 
	



 it('Test create order request Trunkig', function(){	
	genericFlow.flow("create_order_flow", "trunking");	       
	},15000000); 
	

it('Test create order request Transport Special Access', function(){	
	genericFlow.flow("create_order_flow", "transport_s");	       
	},15000000);

	it('Test create order request Transport Special Access', function(){	
	genericFlow.flow("create_order_flow", "transport_e");	       
	},15000000); 

 
	 it('Test create order request Ring Service', function(){	
	genericFlow.flow("create_order_flow", "ringService");	       
	},15000000); 



 it('Test create order request Feature Group A', function(){	
	genericFlow.flow("create_order_flow", "featureGroupA");	       
	},1500000)



it('Test create order request Trunkig', function(){	
	genericFlow.flow("create_order_flow", "watsAccessLines");	       
	},1500000)



it('Test create order request Trunkig', function(){	
		genericFlow.flow("create_order_flow", "virtualConnection");	       
	},1500000);



 it('Test create order request PVC Standalone', function(){	
genericFlow.flow("create_order_flow", "pvc_standalone");	       
}, 1500000); //  working 


it('Test create order request  Dedicated Internet Service', function(){	
genericFlow.flow("create_order_flow", "dis");	       
}, 1500000); 

	 //Supplement Order Flow

	it('Test Supplement order Swithed Ethernet UNI EU', function(){	
		genericFlow.flow("supplement_order_flow", "edit_unieu",'async');	       
	},1500000); 

	it('Test Supplement order  Swithed Ethernet UNI EU-EVC', function(){	
		genericFlow.flow("supplement_order_flow", "edit_unieuevc",'async');	       
		},1500000); 


it('Test Supplement order Swithed Ethernet UNI-NNI-POP', function(){	
		genericFlow.flow("supplement_order_flow", "edit_uninnipop",'async');	       
	},1500000); 

	it('Test Supplement order Swithed Ethernet UNI-POP-EVC', function(){	
		genericFlow.flow("supplement_order_flow", "edit_uninnipopevc",'async');	       
	},1500000); 

it('Test supplement order request EVC Standalone', function(){	
		genericFlow.flow("supplement_order_flow", "edit_evcStandalone");	       
	},1500000); 

	it('Test Supplement order request Trunkig', function(){	
		genericFlow.flow("supplement_order_flow", "edit_trunking",'async');	       
	},1500000); 


it('Test Supplement order request Transport-S', function(){	
		genericFlow.flow("supplement_order_flow", "edit_transport_s",'async');	       
	},1500000); 


it('Test Supplement order request Feature Group A', function(){	
		genericFlow.flow("supplement_order_flow", "edit_featureGroupA",'async');	       
	},1500000); 

	
	it('Test Supplement order request Ring Service', function(){	
		genericFlow.flow("supplement_order_flow", "edit_ringService",'async');	       
	},1500000); 

	

it('Test supplement order  watsAccessLines', function(){	
	genericFlow.flow("supplement_order_flow", "edit_watsAccessLines",'async');	       
	})

it('Test create order request Trunkig', function(){	
		genericFlow.flow("create_order_flow", "virtualConnection");	       
	});

it('Test create order request Transport Special Access', function(){	
	genericFlow.flow("create_order_flow", "transport_e");	       
	});



 //Clone Order Flow
it('Test Supplement order Swithed Ethernet UNI EU', function(){	
		genericFlow.flow("clone_order_flow", "clone_unieu",'async');	       
	},1500000); 

	it('Test clone order  Swithed Ethernet UNI EU-EVC', function(){	
		genericFlow.flow("clone_order_flow", "clone_unieuevc",'async');	       
		},1500000); 


it('Test clone order Swithed Ethernet UNI-NNI-POP', function(){	
		genericFlow.flow("clone_order_flow", "clone_uninnipop",'async');	       
	},1500000); 

	it('Test clone order Swithed Ethernet UNI-POP-EVC', function(){	
		genericFlow.flow("clone_order_flow", "clone_uninnipopevc",'async');	       
	},1500000); 

it('Test clone order request EVC Standalone', function(){	
		genericFlow.flow("clone_order_flow", "clone_evcStandalone");	       
	},1500000); 

	it('Test clone order request Trunkig', function(){	
		genericFlow.flow("clone_order_flow", "clone_trunking",'async');	       
	},1500000); 


it('Test clone order request Transport-S', function(){	
		genericFlow.flow("clone_order_flow", "clone_transport_s",'async');	       
	},1500000); 


it('Test clone order request Feature Group A', function(){	
		genericFlow.flow("clone_order_flow", "clone_featureGroupA",'async');	       
	},1500000); 

	
	it('Test clone order request Ring Service', function(){	
		genericFlow.flow("clone_order_flow", "clone_ringService",'async');	       
	},1500000); 

	

it('Test supplement order  watsAccessLines', function(){	
	genericFlow.flow("supplement_order_flow", "supplement_watsAccessLines",'async');	       
	},1500000)//not working




it('Test supplement order  DIS ', function(){	
	genericFlow.flow("supplement_order_flow", "edit_dis",'async');	       
	},1500000)// working

it('Test supplement order  PVC ', function(){	
	genericFlow.flow("supplement_order_flow", "edit_pvc",'async');	       
	},1500000)// working



it('Test create order request Trunkig', function(){	
		genericFlow.flow("create_order_flow", "virtualConnection");	       
	});

it('Test create order request Transport Special Access', function(){	
	genericFlow.flow("create_order_flow", "transport_e");	       
	});

// Response Submission from Order detail screen

it('Send Confirmation response for UNI EU', function(){	
	genericFlow.flow("response_flow", "confirmation_response_for_unieu",'async');	       
	},1000000)

it('Send Confirmation response for UNI EU', function(){	
	genericFlow.flow("response_flow", "secondary_confirmation_response_for_unieu",'async');	       
	},1000000)


	
it('Send DLR RESPONSE OVER UNIEU', function(){	
	genericFlow.flow("response_flow", "dlr_response_for_unieu",'async');	       
	},1000000)

it('Test supplement order  watsAccessLines', function(){	
		genericFlow.flow("response_flow", "clarification_response_for_unieu",'async');	       
	})  


it('Test create Preorder Address Validation Inquiry', function(){	
	genericFlow.flow("create_preorder_flow", "create_preorder_address_validation_inquiry_by_address",'async');	       
	},100000)


it('Test create Preorder Address Validation Inquiry', function(){	
	genericFlow.flow("create_preorder_flow", "create_preorder_address_validation_inquiry_by_circuit",'async');	       
	},100000)

it('Test create Preorder Address Validation Inquiry', function(){	
	genericFlow.flow("create_preorder_flow", "create_preorder_address_validation_inquiry_by_working_telephone_number",'async');	       
	},100000)


it('Test create Preorder Service Availability Inquiry', function(){	
	genericFlow.flow("create_preorder_flow", "create_preorder_service_availability_inquiry",'async');	       
	},150000000)


it('Test create Preorder CFA Validation Inquiry', function(){	
	genericFlow.flow("create_preorder_flow", "create_preorder_CFA_validation_inquiry",'async');	       
	},150000000)

//it('Test create DLR response for UNI EU', function(){	
//	genericFlow.flow("create_response_flow", "create_dlr_response_for_unieu");	       
//	},150000000);
*/

});