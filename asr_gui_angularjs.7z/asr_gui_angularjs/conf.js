// An example configuration file.
var env = require('./environment.js');
exports.config = {
  directConnect: false,

  // Capabilities to be passed to the webdriver instance.
  capabilities: {
    'browserName': 'chrome'
  },

  // Framework to use. Jasmine is recommended.
  framework: 'jasmine',

  // Spec patterns are relative to the current working directly when
  // protractor is called.
  specs: ['create_order_spec.js'],
  allScriptsTimeout: 6000000,

  // Options to be passed to Jasmine.
  
  jasmineNodeOpts: {
    defaultTimeoutInterval: 600000,
	getPageTimeout: 600000,
	allScriptsTimeout: 600000,
	showColors: true, // Use colors in the command line report.
  },
  onPrepare: function () {
	//jasmine.getEnv().addReporter(new SpecReporter());
	},
	  
};