var GenericFlow = require('./generic_flow_controller.js');
var env = require('./environment.js');
describe('user login form', function() {
	
	var ptro;
	var params = browser.params;    		
	var genericFlow = new GenericFlow();  	
	var http = require('http');

	//browser.get(params.url.baseUrl+'login');
	//browser.driver.manage().window().maximize();		
	//console.log(params.url.baseUrl+'login');
	
	browser.get('http://qaasruiweb.va.neustar.com/oms/view/login');
	browser.driver.manage().window().maximize();
	
	beforeEach(function(){
		genericFlow.flow("login_flow", "login");
	});
		
	 afterEach(function(){
		genericFlow.flow("logout_flow", "logout");
	}); 


it('Test ASR Search by PON',function(){

genericFlow.flow("search_order_flow","serachByPON")

},50000);
  
it('Test ASR Search by Trading Partner',function(){

genericFlow.flow("search_order_flow","serachByTradingPartner")

},50000);


it('Test ASR Search by Order Status',function(){

genericFlow.flow("search_order_flow","serachByOrderStatus")

},50000);


it("Test ASR Search by ICSC",function(){

genericFlow.flow("search_order_flow","serachByICSC")

},50000);



it("Test ASR Search by PON and ICSC",function(){

genericFlow.flow("search_order_flow","searchBYPONandICSC")

},50000);

it("Test ASR Send Preorder Search by ICSC",function(){

genericFlow.flow("search_preorder_flow","ASR_PreOrder_Serach_By_ICSC")

},50000);
	
	
});