describe("verify login", function(){
	
	beforeEach(function() {
		
			
		browser.get("http://qaasruiweb.va.neustar.com/oms/view/login");
		browser.sleep("3000");
		browser.driver.manage().window().maximize();
	});
	
	
	
	it("Search by PON", function(){
		
		
		
		element(by.model("login.domain")).sendKeys("ASR_GW");
		element(by.model("login.user")).sendKeys("example");
		element(by.model("login.password")).sendKeys("example");
		element(by.buttonText("Submit")).click();
		
		browser.sleep("3000");
		
		element(by.css(".icon.nuxicon.nuxicon-search")).click();
		browser.sleep("3000");
		element(by.css("#asrSendOrder")).click();
		//browser.waitForAngular();
		browser.sleep("3000");
		browser.actions().mouseMove(element(by.css('.nux-footer>p'))).perform();
	     //expect(element(by.css('.popover-content')).isDisplayed()).toBeTruthy();
		
		
		
		browser.sleep("3000");
		element(by.model("search.PON")).sendKeys("CHPON04648396258");
		browser.sleep("3000");
		element(by.buttonText("Search")).click();
		browser.sleep("3000");
		element(by.css(".ng-scope>td>a")).click();
		element(by.xpath("//*[@id='nux-page']/tab-view/div/div/div[4]/div/div/div/div/div[1]/accordion/div/div[2]/div[2]/div/div[1]/table/tbody/tr[2]/td[1]/a")).click();
		browser.sleep("3000");
		
		element(by.buttonText("Printable View")).click();
		browser.sleep("3000");
		browser.getAllWindowHandles().then(function (handles) {
	        newWindowHandle = handles[1];
	        browser.switchTo().window(newWindowHandle).then(function () {
	            expect(browser.driver.getCurrentUrl()).toBe("http://qaasruiweb.va.neustar.com/oms/view/home");
	            //to close the current window
	            browser.sleep("3000");
	            browser.driver.close().then(function () {
	                //to switch to the previous window
	            	browser.sleep("3000");
	                browser.switchTo().window(handles[0]);
	            });
	 
	        });
	    });
	
		browser.sleep("3000");
		//browser.takeScreenshot();
		element(by.css("#logout_btn")).click();
	});
	
	
	it("Test ASR Search by Trading Partner", function(){
	element(by.model("login.domain")).sendKeys("ASR_GW");
		element(by.model("login.user")).sendKeys("example");
		element(by.model("login.password")).sendKeys("example");
		element(by.buttonText("Submit")).click();
		
		browser.sleep("3000");
		
		element(by.css(".icon.nuxicon.nuxicon-search")).click();
		browser.sleep("3000");
		element(by.css("#asrSendOrder")).click();
		//browser.waitForAngular();
		browser.sleep("3000");
		browser.actions().mouseMove(element(by.css('.nux-footer>p'))).perform();
		browser.sleep("3000");
		
		  
		  element(by.xpath("//*[@id='nux-page']/tab-view/div/div/div[2]/div/div/div/div/div[2]/div/form/div/div[2]/div/label/div[3]/select")).sendKeys("Caviller");
		
		//element(by.css('select option[value="7"]')).click();
		element(by.buttonText("Search")).click();
		browser.sleep("3000");
		element(by.xpath("//*[@id='nux-page']/tab-view/div/div/div[3]/div/div/div/div/div[1]/accordion/div/div[2]/div[2]/div/div[1]/table/tbody/tr[1]/td[1]/a")).click();
		browser.sleep("3000");
		element(by.xpath("//*[@id='nux-page']/tab-view/div/div/div[4]/div/div/div/div/div[1]/accordion/div/div[2]/div[2]/div/div[1]/table/tbody/tr[1]/td[1]/a")).click();
		browser.sleep("3000");
		element(by.buttonText("Printable View")).click();
		browser.sleep("3000");
		browser.getAllWindowHandles().then(function (handles) {
	        newWindowHandle = handles[1];
	        browser.switchTo().window(newWindowHandle).then(function () {
	            expect(browser.driver.getCurrentUrl()).toBe("http://qaasruiweb.va.neustar.com/oms/view/home");
	            //to close the current window
	            browser.sleep("3000");
	            browser.driver.close().then(function () {
	                //to switch to the previous window
	            	browser.sleep("3000");
	                browser.switchTo().window(handles[0]);
	            });
	 
	        });
	    });
	
		browser.sleep("3000");
		//browser.takeScreenshot();
		element(by.css("#logout_btn")).click();
	
		
		
	});
	
	it("Test ASR Search by Order Status" , function(){
		element(by.model("login.domain")).sendKeys("ASR_GW");
		element(by.model("login.user")).sendKeys("example");
		element(by.model("login.password")).sendKeys("example");
		element(by.buttonText("Submit")).click();
		
		browser.sleep("3000");
		
		element(by.css(".icon.nuxicon.nuxicon-search")).click();
		browser.sleep("3000");
		element(by.css("#asrSendOrder")).click();
		//browser.waitForAngular();
		browser.sleep("3000");
		browser.actions().mouseMove(element(by.css('.nux-footer>p'))).perform();
		browser.sleep("3000");
		
		element(by.xpath("//*[@id='nux-page']/tab-view/div/div/div[2]/div/div/div/div/div[2]/div/form/div/div[2]/div/label/div[4]/select")).sendKeys("Service Request");
		element(by.buttonText("Search")).click();
		browser.sleep("3000");
		element(by.xpath("//*[@id='nux-page']/tab-view/div/div/div[3]/div/div/div/div/div[1]/accordion/div/div[2]/div[2]/div/div[1]/table/tbody/tr[1]/td[1]/a")).click();
		browser.sleep("3000");
		element(by.xpath("//*[@id='nux-page']/tab-view/div/div/div[4]/div/div/div/div/div[1]/accordion/div/div[2]/div[2]/div/div[1]/table/tbody/tr[1]/td[1]/a")).click();
		browser.sleep("3000");
		element(by.buttonText("Printable View")).click();
		browser.sleep("3000");
		browser.getAllWindowHandles().then(function (handles) {
	        newWindowHandle = handles[1];
	        browser.switchTo().window(newWindowHandle).then(function () {
	            expect(browser.driver.getCurrentUrl()).toBe("http://qaasruiweb.va.neustar.com/oms/view/home");
	            //to close the current window
	            browser.sleep("3000");
	            browser.driver.close().then(function () {
	                //to switch to the previous window
	            	browser.sleep("3000");
	                browser.switchTo().window(handles[0]);
	            });
	 
	        });
	    });
	
		browser.sleep("3000");
		//browser.takeScreenshot();
		element(by.css("#logout_btn")).click();
	});
	
	it("Search by ICSC", function(){
		
		//browser.get("http://qaasruiweb.va.neustar.com/oms/view/login");
		//browser.sleep("3000");
		element(by.model("login.domain")).sendKeys("ASR_GW");
		element(by.model("login.user")).sendKeys("example");
		element(by.model("login.password")).sendKeys("example");
		element(by.buttonText("Submit")).click();
		
		browser.sleep("3000");
		element(by.css(".icon.nuxicon.nuxicon-search")).click();
		browser.sleep("3000");
		element(by.css("#asrSendOrder")).click();
		//browser.waitForAngular();
		browser.sleep("3000");
		browser.actions().mouseMove(element(by.css('.nux-footer>p'))).perform();
	    		
		browser.sleep("3000");
		
		element(by.model("search.ICSC")).sendKeys("SB01");
		browser.sleep("3000");
		element(by.buttonText("Search")).click();
		browser.sleep("3000");
		element(by.css(".ng-scope>td>a")).click();
		element(by.xpath("//*[@id='nux-page']/tab-view/div/div/div[4]/div/div/div/div/div[1]/accordion/div/div[2]/div[2]/div/div[1]/table/tbody/tr[2]/td[1]/a")).click();
		browser.sleep("3000");
		
		element(by.buttonText("Printable View")).click();
		browser.sleep("3000");
		browser.getAllWindowHandles().then(function (handles) {
	        newWindowHandle = handles[1];
	        browser.switchTo().window(newWindowHandle).then(function () {
	            expect(browser.driver.getCurrentUrl()).toBe("http://qaasruiweb.va.neustar.com/oms/view/home");
	            //to close the current window
	            browser.sleep("3000");
	            browser.driver.close().then(function () {
	                //to switch to the previous window
	            	browser.sleep("3000");
	                browser.switchTo().window(handles[0]);
	            });
	 
	        });
	    });
	
		browser.sleep("3000");
		//browser.takeScreenshot();
		element(by.css("#logout_btn")).click();
	});
	
	it("Search by PON and ICSC", function(){
		
		//browser.get("http://qaasruiweb.va.neustar.com/oms/view/login");
		//browser.sleep("3000");
		element(by.model("login.domain")).sendKeys("ASR_GW");
		element(by.model("login.user")).sendKeys("example");
		element(by.model("login.password")).sendKeys("example");
		element(by.buttonText("Submit")).click();
		
		browser.sleep("3000");
		element(by.css(".icon.nuxicon.nuxicon-search")).click();
		browser.sleep("3000");
		element(by.css("#asrSendOrder")).click();
		//browser.waitForAngular();
		browser.sleep("3000");
		browser.actions().mouseMove(element(by.css('.nux-footer>p'))).perform();
	    		
		browser.sleep("3000");
		
		element(by.model("search.PON")).sendKeys("CHPON04648396258");
		element(by.model("search.ICSC")).sendKeys("NL01");
		browser.sleep("3000");
		element(by.buttonText("Search")).click();
		browser.sleep("3000");
		element(by.css(".ng-scope>td>a")).click();
		element(by.xpath("//*[@id='nux-page']/tab-view/div/div/div[4]/div/div/div/div/div[1]/accordion/div/div[2]/div[2]/div/div[1]/table/tbody/tr[2]/td[1]/a")).click();
		browser.sleep("3000");
		
		element(by.buttonText("Printable View")).click();
		browser.sleep("3000");
		browser.getAllWindowHandles().then(function (handles) {
	        newWindowHandle = handles[1];
	        browser.switchTo().window(newWindowHandle).then(function () {
	            expect(browser.driver.getCurrentUrl()).toBe("http://qaasruiweb.va.neustar.com/oms/view/home");
	            //to close the current window
	            browser.sleep("3000");
	            browser.driver.close().then(function () {
	                //to switch to the previous window
	            	browser.sleep("3000");
	                browser.switchTo().window(handles[0]);
	            });
	 
	        });
	    });
	
		browser.sleep("3000");
		//browser.takeScreenshot();
		element(by.css("#logout_btn")).click();
	});
it("Search By SERVICETYPE", function() {
		
		element(by.model("login.domain")).sendKeys("ASR_GW");
		element(by.model("login.user")).sendKeys("example");
		element(by.model("login.password")).sendKeys("example");
		element(by.buttonText("Submit")).click();
		
		browser.sleep("3000");
		element(by.css(".icon.nuxicon.nuxicon-search")).click();
		browser.sleep("3000");
		element(by.css("#asrSendOrder")).click();
		//browser.waitForAngular();
		browser.sleep("3000");
		browser.actions().mouseMove(element(by.css('.nux-footer>p'))).perform();
	    		
		browser.sleep("3000");
		
		element(by.xpath("//*[@id='nux-page']/tab-view/div/div/div[2]/div/div/div/div/div[2]/div/form/div/div[2]/div/label/div[2]/select")).sendKeys("Dedicated Internet Service");
		element(by.buttonText("Search")).click();
		browser.sleep("3000");
		element(by.css(".ng-scope>td>a")).click();
		element(by.xpath("//*[@id='nux-page']/tab-view/div/div/div[4]/div/div/div/div/div[1]/accordion/div/div[2]/div[2]/div/div[1]/table/tbody/tr[2]/td[1]/a")).click();
		browser.sleep("3000");
		
		element(by.buttonText("Printable View")).click();
		browser.sleep("3000");
		browser.getAllWindowHandles().then(function (handles) {
	        newWindowHandle = handles[1];
	        browser.switchTo().window(newWindowHandle).then(function () {
	            expect(browser.driver.getCurrentUrl()).toBe("http://qaasruiweb.va.neustar.com/oms/view/home");
	            //to close the current window
	            browser.sleep("3000");
	            browser.driver.close().then(function () {
	                //to switch to the previous window
	            	browser.sleep("3000");
	                browser.switchTo().window(handles[0]);
	            });
	 
	        });
	    });
	
		browser.sleep("3000");
		//browser.takeScreenshot();
		element(by.css("#logout_btn")).click();
	});
	
	
	
	it("ASr SEND PREORDER Search by ICSC", function(){
		
		//browser.get("http://qaasruiweb.va.neustar.com/oms/view/login");
		//browser.sleep("3000");
		element(by.model("login.domain")).sendKeys("ASR_GW");
		element(by.model("login.user")).sendKeys("example");
		element(by.model("login.password")).sendKeys("example");
		element(by.buttonText("Submit")).click();
		
		browser.sleep("3000");
		element(by.css(".icon.nuxicon.nuxicon-search")).click();
		browser.sleep("3000");
		element(by.css("#asrPreOrder")).click();
		//browser.waitForAngular();
		browser.sleep("3000");
		browser.actions().mouseMove(element(by.css('.nux-footer>p'))).perform();
	    		
		browser.sleep("3000");
		
		element(by.model("search.ICSC")).sendKeys("SB01");
		browser.sleep("3000");
		element(by.buttonText("Search")).click();
		browser.sleep("3000");
		element(by.xpath("//*[@id='nux-page']/tab-view/div/div/div[3]/div/div/div/div/div[1]/accordion/div/div[2]/div[2]/div/div[1]/table/tbody/tr[1]/td[1]/a")).click();
		element(by.xpath("//*[@id='nux-page']/tab-view/div/div/div[4]/div/div/div/div/div[1]/accordion/div/div[2]/div[2]/div/div[1]/table/tbody/tr[2]/td[1]/a")).click();
		browser.sleep("3000");
		
		element(by.buttonText("Printable View")).click();
		browser.sleep("3000");
		browser.getAllWindowHandles().then(function (handles) {
	        newWindowHandle = handles[1];
	        browser.switchTo().window(newWindowHandle).then(function () {
	            expect(browser.driver.getCurrentUrl()).toBe("http://qaasruiweb.va.neustar.com/oms/view/home");
	            //to close the current window
	            browser.sleep("3000");
	            browser.driver.close().then(function () {
	                //to switch to the previous window
	            	browser.sleep("3000");
	                browser.switchTo().window(handles[0]);k
	            });
	 
	        });
	    });
	
		browser.sleep("3000");
		//browser.takeScreenshot();
		element(by.css("#logout_btn")).click();
	});
	
	it("ASr SEND PREORDER Search by SERVICE TYPE", function(){
	
	element(by.model("login.domain")).sendKeys("ASR_GW");
		element(by.model("login.user")).sendKeys("example");
		element(by.model("login.password")).sendKeys("example");
		element(by.buttonText("Submit")).click();
		
		browser.sleep("3000");
		element(by.css(".icon.nuxicon.nuxicon-search")).click();
		browser.sleep("3000");
		element(by.css("#asrPreOrder")).click();
		//browser.waitForAngular();
		browser.sleep("3000");
		browser.actions().mouseMove(element(by.css('.nux-footer>p'))).perform();
	    		
		browser.sleep("3000");
		
		element(by.xpath("//*[@id='nux-page']/tab-view/div/div/div[2]/div/div/div/div/div[2]/div/form/div/div[2]/div/label/div[2]/select")).sendKeys("CFA Inquiry");
		browser.sleep("3000");
		element(by.buttonText("Search")).click();
		browser.sleep("3000");
		element(by.xpath("//*[@id='nux-page']/tab-view/div/div/div[3]/div/div/div/div/div[1]/accordion/div/div[2]/div[2]/div/div[1]/table/tbody/tr[1]/td[1]/a")).click();
		element(by.xpath("//*[@id='nux-page']/tab-view/div/div/div[4]/div/div/div/div/div[1]/accordion/div/div[2]/div[2]/div/div[1]/table/tbody/tr[2]/td[1]/a")).click();
		browser.sleep("3000");
		
		element(by.buttonText("Printable View")).click();
		browser.sleep("3000");
		browser.getAllWindowHandles().then(function (handles) {
	        newWindowHandle = handles[1];
	        browser.switchTo().window(newWindowHandle).then(function () {
	            expect(browser.driver.getCurrentUrl()).toBe("http://qaasruiweb.va.neustar.com/oms/view/home");
	            //to close the current window
	            browser.sleep("3000");
	            browser.driver.close().then(function () {
	                //to switch to the previous window
	            	browser.sleep("3000");
	                browser.switchTo().window(handles[0]);k
	            });
	 
	        });
	    });
	
		browser.sleep("3000");
		//browser.takeScreenshot();
		element(by.css("#logout_btn")).click();
	
	});
	
	it("ASr SEND PREORDER Search by STATUS", function(){
	
	element(by.model("login.domain")).sendKeys("ASR_GW");
		element(by.model("login.user")).sendKeys("example");
		element(by.model("login.password")).sendKeys("example");
		element(by.buttonText("Submit")).click();
		
		browser.sleep("3000");
		element(by.css(".icon.nuxicon.nuxicon-search")).click();
		browser.sleep("3000");
		element(by.css("#asrPreOrder")).click();
		//browser.waitForAngular();
		browser.sleep("3000");
		browser.actions().mouseMove(element(by.css('.nux-footer>p'))).perform();
	    		
		browser.sleep("3000");
		
		element(by.xpath("//*[@id='nux-page']/tab-view/div/div/div[2]/div/div/div/div/div[2]/div/form/div/div[2]/div/label/div[4]/select")).sendKeys("CFA Inquiry");
		browser.sleep("3000");
		element(by.buttonText("Search")).click();
		browser.sleep("3000");
		element(by.xpath("//*[@id='nux-page']/tab-view/div/div/div[3]/div/div/div/div/div[1]/accordion/div/div[2]/div[2]/div/div[1]/table/tbody/tr[1]/td[1]/a")).click();
		element(by.xpath("//*[@id='nux-page']/tab-view/div/div/div[4]/div/div/div/div/div[1]/accordion/div/div[2]/div[2]/div/div[1]/table/tbody/tr[2]/td[1]/a")).click();
		browser.sleep("3000");
		
		element(by.buttonText("Printable View")).click();
		browser.sleep("3000");
		browser.getAllWindowHandles().then(function (handles) {
	        newWindowHandle = handles[1];
	        browser.switchTo().window(newWindowHandle).then(function () {
	            expect(browser.driver.getCurrentUrl()).toBe("http://qaasruiweb.va.neustar.com/oms/view/home");
	            //to close the current window
	            browser.sleep("3000");
	            browser.driver.close().then(function () {
	                //to switch to the previous window
	            	browser.sleep("3000");
	                browser.switchTo().window(handles[0]);k
	            });
	 
	        });
	    });
	
		browser.sleep("3000");
		//browser.takeScreenshot();
		element(by.css("#logout_btn")).click();
	
	});
	
	it("ASr SEND PREORDER Search by TRADING PARTNER", function(){
	element(by.model("login.domain")).sendKeys("ASR_GW");
		element(by.model("login.user")).sendKeys("example");
		element(by.model("login.password")).sendKeys("example");
		element(by.buttonText("Submit")).click();
		
		browser.sleep("3000");
		element(by.css(".icon.nuxicon.nuxicon-search")).click();
		browser.sleep("3000");
		element(by.css("#asrPreOrder")).click();
		//browser.waitForAngular();
		browser.sleep("3000");
		browser.actions().mouseMove(element(by.css('.nux-footer>p'))).perform();
	    		
		browser.sleep("3000");
		
		element(by.xpath("//*[@id='nux-page']/tab-view/div/div/div[2]/div/div/div/div/div[2]/div/form/div/div[2]/div/label/div[3]/select")).sendKeys("QWEST");
		browser.sleep("3000");
		element(by.buttonText("Search")).click();
		browser.sleep("3000");
		element(by.xpath("//*[@id='nux-page']/tab-view/div/div/div[3]/div/div/div/div/div[1]/accordion/div/div[2]/div[2]/div/div[1]/table/tbody/tr[1]/td[1]/a")).click();
		element(by.xpath("//*[@id='nux-page']/tab-view/div/div/div[4]/div/div/div/div/div[1]/accordion/div/div[2]/div[2]/div/div[1]/table/tbody/tr[2]/td[1]/a")).click();
		browser.sleep("3000");
		
		element(by.buttonText("Printable View")).click();
		browser.sleep("3000");
		browser.getAllWindowHandles().then(function (handles) {
	        newWindowHandle = handles[1];
	        browser.switchTo().window(newWindowHandle).then(function () {
	            expect(browser.driver.getCurrentUrl()).toBe("http://qaasruiweb.va.neustar.com/oms/view/home");
	            //to close the current window
	            browser.sleep("3000");
	            browser.driver.close().then(function () {
	                //to switch to the previous window
	            	browser.sleep("3000");
	                browser.switchTo().window(handles[0]);k
	            });
	 
	        });
	    });
	
		browser.sleep("3000");
		//browser.takeScreenshot();
		element(by.css("#logout_btn")).click();
	
	});
	
	
	
	
	
});