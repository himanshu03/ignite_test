//var objects = require('./Objects.json');

describe("Creating forms",function(){
	
beforeEach(function() {
		
		
		browser.get("http://qaasruiweb.va.neustar.com/oms/view/login");
		browser.sleep("3000");
		//browser.driver.manage().window().maximize();
		element(by.model("login.domain")).sendKeys("ASR_GW");
		element(by.model("login.user")).sendKeys("example");
		element(by.model("login.password")).sendKeys("example");
		element(by.buttonText("SUBMIT")).click();
		element(by.css(".icon.batchicon.batchicon_285")).click();
				
	});

afterEach(function() {
	
	browser.sleep("3000");
	element(by.xpath("//*[@id='logout_btn']")).click();
	
	//element(by.buttonText("logout()")).click();
	
});



it("Switched ethernet with UNI AT E", function() {
	
	
	element(by.xpath("html/body/div[3]/div/div/form/div[2]/div[2]/table/tbody/tr[10]/td/label/select")).sendKeys("Caviller");
	element(by.buttonText("NEXT >")).click();
	element(by.buttonText("CREATE")).click();
	browser.sleep("2000");
	
	
});

it("Swithched Ethernet with EVC", function() {
	
	element(by.xpath("html/body/div[3]/div/div/form/div[2]/div[2]/table/tbody/tr[10]/td/label/select")).sendKeys("Caviller");
	element(by.buttonText("NEXT >")).click();
	element(by.xpath("html/body/div[3]/div/div/form/div[2]/div/div/table[2]/tbody/tr[3]/td/label/input")).click();
	element(by.buttonText("CREATE")).click();
	browser.sleep("2000");
	
	
});

it("Switched Ethernet with POP", function() {
	
	element(by.xpath("html/body/div[3]/div/div/form/div[2]/div[2]/table/tbody/tr[10]/td/label/select")).sendKeys("Caviller");
	element(by.buttonText("NEXT >")).click();
	element(by.xpath("html/body/div[3]/div/div/form/div[2]/div/div/table[2]/tbody/tr[4]/td/label/input")).click();
	element(by.buttonText("CREATE")).click();
	browser.sleep("2000");
	
	
});

it("Switched Ethernet POP with MVC", function() {
	
	element(by.xpath("html/body/div[3]/div/div/form/div[2]/div[2]/table/tbody/tr[10]/td/label/select")).sendKeys("Caviller");
	element(by.buttonText("NEXT >")).click();
	element(by.xpath("html/body/div[3]/div/div/form/div[2]/div/div/table[2]/tbody/tr[5]/td/label/input")).click();
	element(by.buttonText("CREATE")).click();
	browser.sleep("2000");
	
});

it("EVC STANDALONE with NEW", function() {
	
	element(by.xpath("html/body/div[3]/div/div/form/div[2]/div[2]/table/tbody/tr[2]/td[2]/label/input")).click();
	element(by.xpath("html/body/div[3]/div/div/form/div[2]/div[2]/table/tbody/tr[10]/td/label/select")).sendKeys("Caviller");
	element(by.buttonText("NEXT >")).click();
	element(by.xpath("html/body/div[3]/div/div/form/div[2]/div/div/table[5]/tbody/tr[2]/td/label/input")).click();
	element(by.buttonText("CREATE")).click();
	browser.sleep("2000");
	
});

it("EVC STANDALONE with Disconnect", function() {
	
	
	element(by.xpath("html/body/div[3]/div/div/form/div[2]/div[2]/table/tbody/tr[2]/td[2]/label/input")).click();
	element(by.xpath("html/body/div[3]/div/div/form/div[2]/div[2]/table/tbody/tr[10]/td/label/select")).sendKeys("Caviller");
	element(by.buttonText("NEXT >")).click();
	element(by.xpath("html/body/div[3]/div/div/form/div[2]/div/div/table[5]/tbody/tr[3]/td/label/input")).click();
	element(by.buttonText("CREATE")).click();
	browser.sleep("2000");
	
});

it("EVC STANDALONE with Change", function() {
	
	element(by.xpath("html/body/div[3]/div/div/form/div[2]/div[2]/table/tbody/tr[2]/td[2]/label/input")).click();
	element(by.xpath("html/body/div[3]/div/div/form/div[2]/div[2]/table/tbody/tr[10]/td/label/select")).sendKeys("Caviller");
	element(by.buttonText("NEXT >")).click();
	element(by.xpath("html/body/div[3]/div/div/form/div[2]/div/div/table[5]/tbody/tr[4]/td/label/input")).click();
	element(by.buttonText("CREATE")).click();
	browser.sleep("2000");
	
});

it("EVC STANDALONE with Records", function() {
	
	element(by.xpath("html/body/div[3]/div/div/form/div[2]/div[2]/table/tbody/tr[2]/td[2]/label/input")).click();
	element(by.xpath("html/body/div[3]/div/div/form/div[2]/div[2]/table/tbody/tr[10]/td/label/select")).sendKeys("Caviller");
	element(by.buttonText("NEXT >")).click();
	element(by.xpath("html/body/div[3]/div/div/form/div[2]/div/div/table[5]/tbody/tr[7]/td/label/input")).click();
	element(by.buttonText("CREATE")).click();
	browser.sleep("2000");
	
});

it("End User Special Access with New", function() {
	
	element(by.xpath("html/body/div[3]/div/div/form/div[2]/div[2]/table/tbody/tr[3]/td[1]/label/input")).click();
	element(by.xpath("html/body/div[3]/div/div/form/div[2]/div[2]/table/tbody/tr[10]/td/label/select")).sendKeys("Caviller");
	element(by.buttonText("NEXT >")).click();
	element(by.xpath("html/body/div[3]/div/div/form/div[2]/div/div/table[5]/tbody/tr[2]/td/label/input")).click();
	element(by.buttonText("CREATE")).click();
	browser.sleep("2000");
	
});

it("End User Special Access with Disconnect", function() {
	
	element(by.xpath("html/body/div[3]/div/div/form/div[2]/div[2]/table/tbody/tr[3]/td[1]/label/input")).click();
	element(by.xpath("html/body/div[3]/div/div/form/div[2]/div[2]/table/tbody/tr[10]/td/label/select")).sendKeys("Caviller");
	element(by.buttonText("NEXT >")).click();
	element(by.xpath("html/body/div[3]/div/div/form/div[2]/div/div/table[5]/tbody/tr[3]/td/label/input")).click();
	element(by.buttonText("CREATE")).click();
	browser.sleep("2000");
	
});

it("End User Special Access with Change", function() {
	
	element(by.xpath("html/body/div[3]/div/div/form/div[2]/div[2]/table/tbody/tr[3]/td[1]/label/input")).click();
	element(by.xpath("html/body/div[3]/div/div/form/div[2]/div[2]/table/tbody/tr[10]/td/label/select")).sendKeys("Caviller");
	element(by.buttonText("NEXT >")).click();
	element(by.xpath("html/body/div[3]/div/div/form/div[2]/div/div/table[5]/tbody/tr[4]/td/label/input")).click();
	element(by.buttonText("CREATE")).click();
	browser.sleep("2000");
	
	
});

it("End User Special Access with Inside Move", function() {
	
	element(by.xpath("html/body/div[3]/div/div/form/div[2]/div[2]/table/tbody/tr[3]/td[1]/label/input")).click();
	element(by.xpath("html/body/div[3]/div/div/form/div[2]/div[2]/table/tbody/tr[10]/td/label/select")).sendKeys("Caviller");
	element(by.buttonText("NEXT >")).click();
	element(by.xpath("html/body/div[3]/div/div/form/div[2]/div/div/table[5]/tbody/tr[5]/td/label/input")).click();
	element(by.buttonText("CREATE")).click();
	browser.sleep("2000");
});

it("End User Special Access with Outside Move", function() {
	
	
	element(by.xpath("html/body/div[3]/div/div/form/div[2]/div[2]/table/tbody/tr[3]/td[1]/label/input")).click();
	element(by.xpath("html/body/div[3]/div/div/form/div[2]/div[2]/table/tbody/tr[10]/td/label/select")).sendKeys("Caviller");
	element(by.buttonText("NEXT >")).click();
	element(by.xpath("html/body/div[3]/div/div/form/div[2]/div/div/table[5]/tbody/tr[6]/td/label/input")).click();
	element(by.buttonText("CREATE")).click();
	browser.sleep("2000");
});

it("End User Special Access with Records", function() {
	
	
	element(by.xpath("html/body/div[3]/div/div/form/div[2]/div[2]/table/tbody/tr[3]/td[1]/label/input")).click();
	element(by.xpath("html/body/div[3]/div/div/form/div[2]/div[2]/table/tbody/tr[10]/td/label/select")).sendKeys("Caviller");
	element(by.buttonText("NEXT >")).click();
	element(by.xpath("html/body/div[3]/div/div/form/div[2]/div/div/table[5]/tbody/tr[7]/td/label/input")).click();
	element(by.buttonText("CREATE")).click();
	browser.sleep("2000");
});

it("Transport special access with New", function() {
	
	element(by.xpath("html/body/div[3]/div/div/form/div[2]/div[2]/table/tbody/tr[3]/td[2]/label/input")).click();
	element(by.xpath("html/body/div[3]/div/div/form/div[2]/div[2]/table/tbody/tr[10]/td/label/select")).sendKeys("Caviller");
	element(by.buttonText("NEXT >")).click();
	element(by.xpath("html/body/div[3]/div/div/form/div[2]/div/div/table[5]/tbody/tr[2]/td/label/input")).click();
	element(by.buttonText("CREATE")).click();
	browser.sleep("2000");
	
});


it("Transport special access with New", function() {
	
	element(by.xpath("html/body/div[3]/div/div/form/div[2]/div[2]/table/tbody/tr[3]/td[2]/label/input")).click();
	element(by.xpath("html/body/div[3]/div/div/form/div[2]/div[2]/table/tbody/tr[10]/td/label/select")).sendKeys("Caviller");
	element(by.buttonText("NEXT >")).click();
	element(by.xpath("html/body/div[3]/div/div/form/div[2]/div/div/table[5]/tbody/tr[3]/td/label/input")).click();
	element(by.buttonText("CREATE")).click();
	browser.sleep("2000");
	
});


it("Transport special access with New", function() {
	
	element(by.xpath("html/body/div[3]/div/div/form/div[2]/div[2]/table/tbody/tr[3]/td[2]/label/input")).click();
	element(by.xpath("html/body/div[3]/div/div/form/div[2]/div[2]/table/tbody/tr[10]/td/label/select")).sendKeys("Caviller");
	element(by.buttonText("NEXT >")).click();
	element(by.xpath("html/body/div[3]/div/div/form/div[2]/div/div/table[5]/tbody/tr[4]/td/label/input")).click();
	element(by.buttonText("CREATE")).click();
	browser.sleep("2000");
	
});


it("Transport special access with New", function() {
	
	element(by.xpath("html/body/div[3]/div/div/form/div[2]/div[2]/table/tbody/tr[3]/td[2]/label/input")).click();
	element(by.xpath("html/body/div[3]/div/div/form/div[2]/div[2]/table/tbody/tr[10]/td/label/select")).sendKeys("Caviller");
	element(by.buttonText("NEXT >")).click();
	element(by.xpath("html/body/div[3]/div/div/form/div[2]/div/div/table[5]/tbody/tr[5]/td/label/input")).click();
	element(by.buttonText("CREATE")).click();
	browser.sleep("2000");
	
});


it("Transport special access with New", function() {
	
	element(by.xpath("html/body/div[3]/div/div/form/div[2]/div[2]/table/tbody/tr[3]/td[2]/label/input")).click();
	element(by.xpath("html/body/div[3]/div/div/form/div[2]/div[2]/table/tbody/tr[10]/td/label/select")).sendKeys("Caviller");
	element(by.buttonText("NEXT >")).click();
	element(by.xpath("html/body/div[3]/div/div/form/div[2]/div/div/table[5]/tbody/tr[6]/td/label/input")).click();
	element(by.buttonText("CREATE")).click();
	browser.sleep("2000");
	
});


it("Transport special access with New", function() {
	
	element(by.xpath("html/body/div[3]/div/div/form/div[2]/div[2]/table/tbody/tr[3]/td[2]/label/input")).click();
	element(by.xpath("html/body/div[3]/div/div/form/div[2]/div[2]/table/tbody/tr[10]/td/label/select")).sendKeys("Caviller");
	element(by.buttonText("NEXT >")).click();
	element(by.xpath("html/body/div[3]/div/div/form/div[2]/div/div/table[5]/tbody/tr[7]/td/label/input")).click();
	element(by.buttonText("CREATE")).click();
	browser.sleep("2000");
	
});



it("Trunking with New", function() {
	
	element(by.xpath("html/body/div[3]/div/div/form/div[2]/div[2]/table/tbody/tr[4]/td[1]/label/input")).click();
	element(by.xpath("html/body/div[3]/div/div/form/div[2]/div[2]/table/tbody/tr[10]/td/label/select")).sendKeys("Caviller");
	element(by.buttonText("NEXT >")).click();
	element(by.xpath("html/body/div[3]/div/div/form/div[2]/div/div/table[5]/tbody/tr[2]/td/label/input")).click();
	element(by.xpath("html/body/div[3]/div/div/form/div[2]/div/div/table[13]/tbody/tr[2]/td/label/input")).sendKeys("2");
	element(by.buttonText("CREATE")).click();
	browser.sleep("2000");
	
});

it("Trunking with Dosconnect", function() {
	
	element(by.xpath("html/body/div[3]/div/div/form/div[2]/div[2]/table/tbody/tr[4]/td[1]/label/input")).click();
	element(by.xpath("html/body/div[3]/div/div/form/div[2]/div[2]/table/tbody/tr[10]/td/label/select")).sendKeys("Caviller");
	element(by.buttonText("NEXT >")).click();
	element(by.xpath("html/body/div[3]/div/div/form/div[2]/div/div/table[5]/tbody/tr[3]/td/label/input")).click();
	element(by.xpath("html/body/div[3]/div/div/form/div[2]/div/div/table[13]/tbody/tr[2]/td/label/input")).sendKeys("2");
	element(by.buttonText("CREATE")).click();
	browser.sleep("2000");
	
});

it("Trunking with Change", function() {
	
	element(by.xpath("html/body/div[3]/div/div/form/div[2]/div[2]/table/tbody/tr[4]/td[1]/label/input")).click();
	element(by.xpath("html/body/div[3]/div/div/form/div[2]/div[2]/table/tbody/tr[10]/td/label/select")).sendKeys("Caviller");
	element(by.buttonText("NEXT >")).click();
	element(by.xpath("html/body/div[3]/div/div/form/div[2]/div/div/table[5]/tbody/tr[4]/td/label/input")).click();
	element(by.xpath("html/body/div[3]/div/div/form/div[2]/div/div/table[13]/tbody/tr[2]/td/label/input")).sendKeys("2");
	element(by.buttonText("CREATE")).click();
	browser.sleep("2000");
	
});


it("Trunking with Records", function() {
	
	element(by.xpath("html/body/div[3]/div/div/form/div[2]/div[2]/table/tbody/tr[4]/td[1]/label/input")).click();
	element(by.xpath("html/body/div[3]/div/div/form/div[2]/div[2]/table/tbody/tr[10]/td/label/select")).sendKeys("Caviller");
	element(by.buttonText("NEXT >")).click();
	element(by.xpath("html/body/div[3]/div/div/form/div[2]/div/div/table[5]/tbody/tr[7]/td/label/input")).click();
	element(by.xpath("html/body/div[3]/div/div/form/div[2]/div/div/table[13]/tbody/tr[2]/td/label/input")).sendKeys("2");
	element(by.buttonText("CREATE")).click();
	browser.sleep("2000");
	
});



it("Virtual Connection with End user as NEw", function() {
	
	element(by.xpath("html/body/div[3]/div/div/form/div[2]/div[2]/table/tbody/tr[4]/td[2]/label/input")).click();
	element(by.xpath("html/body/div[3]/div/div/form/div[2]/div[2]/table/tbody/tr[10]/td/label/select")).sendKeys("Caviller");
	element(by.buttonText("NEXT >")).click();
	browser.sleep("3000");
	element(by.xpath("html/body/div[3]/div/div/form/div[2]/div/div/table[4]/tbody/tr[2]/td/label/input")).click();
	//element(by.buttonText("CREATE")).click();
	browser.sleep("3000");
	element(by.xpath("html/body/div[3]/div/div/form/div[2]/div/div/table[5]/tbody/tr[2]/td/label/input")).click();
	element(by.buttonText("CREATE")).click();
	browser.sleep("3000");
});


it("Virtual Connection with End user as Disconnect", function() {
	
	element(by.xpath("html/body/div[3]/div/div/form/div[2]/div[2]/table/tbody/tr[4]/td[2]/label/input")).click();
	element(by.xpath("html/body/div[3]/div/div/form/div[2]/div[2]/table/tbody/tr[10]/td/label/select")).sendKeys("Caviller");
	element(by.buttonText("NEXT >")).click();
	element(by.xpath("html/body/div[3]/div/div/form/div[2]/div/div/table[4]/tbody/tr[2]/td/label/input")).click();
	//element(by.buttonText("CREATE")).click();
	element(by.xpath("html/body/div[3]/div/div/form/div[2]/div/div/table[5]/tbody/tr[3]/td/label/input")).click();
	element(by.buttonText("CREATE")).click();
	
});	
	

it("Virtual Connection with End user as Change", function() {
	
	element(by.xpath("html/body/div[3]/div/div/form/div[2]/div[2]/table/tbody/tr[4]/td[2]/label/input")).click();
	element(by.xpath("html/body/div[3]/div/div/form/div[2]/div[2]/table/tbody/tr[10]/td/label/select")).sendKeys("Caviller");
	element(by.buttonText("NEXT >")).click();
	element(by.xpath("html/body/div[3]/div/div/form/div[2]/div/div/table[4]/tbody/tr[2]/td/label/input")).click();
	//element(by.buttonText("CREATE")).click();
	element(by.xpath("html/body/div[3]/div/div/form/div[2]/div/div/table[5]/tbody/tr[4]/td/label/input")).click();
	element(by.buttonText("CREATE")).click();
	
});


it("Virtual Connection with End user as Inside Move", function() {
	
	element(by.xpath("html/body/div[3]/div/div/form/div[2]/div[2]/table/tbody/tr[4]/td[2]/label/input")).click();
	element(by.xpath("html/body/div[3]/div/div/form/div[2]/div[2]/table/tbody/tr[10]/td/label/select")).sendKeys("Caviller");
	element(by.buttonText("NEXT >")).click();
	element(by.xpath("html/body/div[3]/div/div/form/div[2]/div/div/table[4]/tbody/tr[2]/td/label/input")).click();
	//element(by.buttonText("CREATE")).click();
	element(by.xpath("html/body/div[3]/div/div/form/div[2]/div/div/table[5]/tbody/tr[5]/td/label/input")).click();
	element(by.buttonText("CREATE")).click();
	
});


it("Virtual Connection with End user as Outside Move", function() {
	
	element(by.xpath("html/body/div[3]/div/div/form/div[2]/div[2]/table/tbody/tr[4]/td[2]/label/input")).click();
	element(by.xpath("html/body/div[3]/div/div/form/div[2]/div[2]/table/tbody/tr[10]/td/label/select")).sendKeys("Caviller");
	element(by.buttonText("NEXT >")).click();
	element(by.xpath("html/body/div[3]/div/div/form/div[2]/div/div/table[4]/tbody/tr[2]/td/label/input")).click();
	//element(by.buttonText("CREATE")).click();
	element(by.xpath("html/body/div[3]/div/div/form/div[2]/div/div/table[5]/tbody/tr[6]/td/label/input")).click();
	element(by.buttonText("CREATE")).click();
	
});


it("Virtual Connection with End user as Records", function() {
	
	element(by.xpath("html/body/div[3]/div/div/form/div[2]/div[2]/table/tbody/tr[4]/td[2]/label/input")).click();
	element(by.xpath("html/body/div[3]/div/div/form/div[2]/div[2]/table/tbody/tr[10]/td/label/select")).sendKeys("Caviller");
	element(by.buttonText("NEXT >")).click();
	element(by.xpath("html/body/div[3]/div/div/form/div[2]/div/div/table[4]/tbody/tr[2]/td/label/input")).click();
	//element(by.buttonText("CREATE")).click();
	element(by.xpath("html/body/div[3]/div/div/form/div[2]/div/div/table[5]/tbody/tr[7]/td/label/input")).click();
	element(by.buttonText("CREATE")).click();
	
});

	


it("Virtual connection with new", function() {
	
	element(by.xpath("html/body/div[3]/div/div/form/div[2]/div[2]/table/tbody/tr[4]/td[2]/label/input")).click();
	element(by.xpath("html/body/div[3]/div/div/form/div[2]/div[2]/table/tbody/tr[10]/td/label/select")).sendKeys("Caviller");
	element(by.buttonText("NEXT >")).click();
	element(by.xpath("html/body/div[3]/div/div/form/div[2]/div/div/table[4]/tbody/tr[3]/td/label/input")).click();
	//element(by.buttonText("CREATE")).click();
	browser.sleep("3000");
	element(by.xpath("html/body/div[3]/div/div/form/div[2]/div/div/table[5]/tbody/tr[2]/td/label/input")).click();
	element(by.buttonText("CREATE")).click();
	
	
});

it("Virtual connect with disconnect", function() {
	
	element(by.xpath("html/body/div[3]/div/div/form/div[2]/div[2]/table/tbody/tr[4]/td[2]/label/input")).click();
	element(by.xpath("html/body/div[3]/div/div/form/div[2]/div[2]/table/tbody/tr[10]/td/label/select")).sendKeys("Caviller");
	element(by.buttonText("NEXT >")).click();
	element(by.xpath("html/body/div[3]/div/div/form/div[2]/div/div/table[4]/tbody/tr[3]/td/label/input")).click();
	//element(by.buttonText("CREATE")).click();
	browser.sleep("3000");
	element(by.xpath("html/body/div[3]/div/div/form/div[2]/div/div/table[5]/tbody/tr[3]/td/label/input")).click();
	element(by.buttonText("CREATE")).click();
	
});

it("Virtual connect with Change", function() {
	
	element(by.xpath("html/body/div[3]/div/div/form/div[2]/div[2]/table/tbody/tr[4]/td[2]/label/input")).click();
	element(by.xpath("html/body/div[3]/div/div/form/div[2]/div[2]/table/tbody/tr[10]/td/label/select")).sendKeys("Caviller");
	element(by.buttonText("NEXT >")).click();
	element(by.xpath("html/body/div[3]/div/div/form/div[2]/div/div/table[4]/tbody/tr[3]/td/label/input")).click();
	//element(by.buttonText("CREATE")).click();
	browser.sleep("3000");
	element(by.xpath("html/body/div[3]/div/div/form/div[2]/div/div/table[5]/tbody/tr[4]/td/label/input")).click();
	element(by.buttonText("CREATE")).click();
});



it("Virtual connect with Records", function() {
	
	element(by.xpath("html/body/div[3]/div/div/form/div[2]/div[2]/table/tbody/tr[4]/td[2]/label/input")).click();
	element(by.xpath("html/body/div[3]/div/div/form/div[2]/div[2]/table/tbody/tr[10]/td/label/select")).sendKeys("Caviller");
	element(by.buttonText("NEXT >")).click();
	element(by.xpath("html/body/div[3]/div/div/form/div[2]/div/div/table[4]/tbody/tr[3]/td/label/input")).click();
	//element(by.buttonText("CREATE")).click();
	browser.sleep("3000");
	element(by.xpath("html/body/div[3]/div/div/form/div[2]/div/div/table[5]/tbody/tr[7]/td/label/input")).click();
	element(by.buttonText("CREATE")).click();
});




it("Ring service with New", function() {
	
	element(by.xpath("html/body/div[3]/div/div/form/div[2]/div[2]/table/tbody/tr[5]/td[1]/label/input")).click();
	element(by.xpath("html/body/div[3]/div/div/form/div[2]/div[2]/table/tbody/tr[10]/td/label/select")).sendKeys("Caviller");
	element(by.buttonText("NEXT >")).click();
	element(by.xpath("html/body/div[3]/div/div/form/div[2]/div/div/table[5]/tbody/tr[2]/td/label/input")).click();
	element(by.buttonText("CREATE")).click();
	
});


it("Ring service with Disconnect", function() {
	
	element(by.xpath("html/body/div[3]/div/div/form/div[2]/div[2]/table/tbody/tr[5]/td[1]/label/input")).click();
	element(by.xpath("html/body/div[3]/div/div/form/div[2]/div[2]/table/tbody/tr[10]/td/label/select")).sendKeys("Caviller");
	element(by.buttonText("NEXT >")).click();
	element(by.xpath("html/body/div[3]/div/div/form/div[2]/div/div/table[5]/tbody/tr[3]/td/label/input")).click();
	element(by.buttonText("CREATE")).click();
	
});


it("Ring service with Change", function() {
	
	element(by.xpath("html/body/div[3]/div/div/form/div[2]/div[2]/table/tbody/tr[5]/td[1]/label/input")).click();
	element(by.xpath("html/body/div[3]/div/div/form/div[2]/div[2]/table/tbody/tr[10]/td/label/select")).sendKeys("Caviller");
	element(by.buttonText("NEXT >")).click();
	element(by.xpath("html/body/div[3]/div/div/form/div[2]/div/div/table[5]/tbody/tr[4]/td/label/input")).click();
	element(by.buttonText("CREATE")).click();
	
});


it("Ring service with Inside move", function() {
	
	element(by.xpath("html/body/div[3]/div/div/form/div[2]/div[2]/table/tbody/tr[5]/td[1]/label/input")).click();
	element(by.xpath("html/body/div[3]/div/div/form/div[2]/div[2]/table/tbody/tr[10]/td/label/select")).sendKeys("Caviller");
	element(by.buttonText("NEXT >")).click();
	element(by.xpath("html/body/div[3]/div/div/form/div[2]/div/div/table[5]/tbody/tr[5]/td/label/input")).click();
	element(by.buttonText("CREATE")).click();
	
});


it("Ring service with Outside Move", function() {
	
	element(by.xpath("html/body/div[3]/div/div/form/div[2]/div[2]/table/tbody/tr[5]/td[1]/label/input")).click();
	element(by.xpath("html/body/div[3]/div/div/form/div[2]/div[2]/table/tbody/tr[10]/td/label/select")).sendKeys("Caviller");
	element(by.buttonText("NEXT >")).click();
	element(by.xpath("html/body/div[3]/div/div/form/div[2]/div/div/table[5]/tbody/tr[6]/td/label/input")).click();
	element(by.buttonText("CREATE")).click();
	
});


it("Ring service with Records", function() {
	
	element(by.xpath("html/body/div[3]/div/div/form/div[2]/div[2]/table/tbody/tr[5]/td[1]/label/input")).click();
	element(by.xpath("html/body/div[3]/div/div/form/div[2]/div[2]/table/tbody/tr[10]/td/label/select")).sendKeys("Caviller");
	element(by.buttonText("NEXT >")).click();
	element(by.xpath("html/body/div[3]/div/div/form/div[2]/div/div/table[5]/tbody/tr[7]/td/label/input")).click();
	element(by.buttonText("CREATE")).click();
	
});




it("Feature Group with New", function() {
	
	element(by.xpath("html/body/div[3]/div/div/form/div[2]/div[2]/table/tbody/tr[5]/td[2]/label/input")).click();
	element(by.xpath("html/body/div[3]/div/div/form/div[2]/div[2]/table/tbody/tr[10]/td/label/select")).sendKeys("Caviller");
	element(by.buttonText("NEXT >")).click();
	element(by.xpath("html/body/div[3]/div/div/form/div[2]/div/div/table[5]/tbody/tr[2]/td/label/input")).click();
	element(by.buttonText("CREATE")).click();
	
});

it("Feature Group with Disconnect", function() {
	
	element(by.xpath("html/body/div[3]/div/div/form/div[2]/div[2]/table/tbody/tr[5]/td[2]/label/input")).click();
	element(by.xpath("html/body/div[3]/div/div/form/div[2]/div[2]/table/tbody/tr[10]/td/label/select")).sendKeys("Caviller");
	element(by.buttonText("NEXT >")).click();
	element(by.xpath("html/body/div[3]/div/div/form/div[2]/div/div/table[5]/tbody/tr[3]/td/label/input")).click();
	element(by.buttonText("CREATE")).click();
	
});

it("Feature Group with Change", function() {
	
	element(by.xpath("html/body/div[3]/div/div/form/div[2]/div[2]/table/tbody/tr[5]/td[2]/label/input")).click();
	element(by.xpath("html/body/div[3]/div/div/form/div[2]/div[2]/table/tbody/tr[10]/td/label/select")).sendKeys("Caviller");
	element(by.buttonText("NEXT >")).click();
	element(by.xpath("html/body/div[3]/div/div/form/div[2]/div/div/table[5]/tbody/tr[4]/td/label/input")).click();
	element(by.buttonText("CREATE")).click();
	
});

it("Feature Group with Inside Move", function() {
	
	element(by.xpath("html/body/div[3]/div/div/form/div[2]/div[2]/table/tbody/tr[5]/td[2]/label/input")).click();
	element(by.xpath("html/body/div[3]/div/div/form/div[2]/div[2]/table/tbody/tr[10]/td/label/select")).sendKeys("Caviller");
	element(by.buttonText("NEXT >")).click();
	element(by.xpath("html/body/div[3]/div/div/form/div[2]/div/div/table[5]/tbody/tr[5]/td/label/input")).click();
	element(by.buttonText("CREATE")).click();
	
});

it("Feature Group with Records", function() {
	
	element(by.xpath("html/body/div[3]/div/div/form/div[2]/div[2]/table/tbody/tr[5]/td[2]/label/input")).click();
	element(by.xpath("html/body/div[3]/div/div/form/div[2]/div[2]/table/tbody/tr[10]/td/label/select")).sendKeys("Caviller");
	element(by.buttonText("NEXT >")).click();
	element(by.xpath("html/body/div[3]/div/div/form/div[2]/div/div/table[5]/tbody/tr[7]/td/label/input")).click();
	element(by.buttonText("CREATE")).click();
	
});

it("WATS with New", function() {
	
	element(by.xpath("html/body/div[3]/div/div/form/div[2]/div[2]/table/tbody/tr[6]/td[1]/label/input")).click();
	element(by.xpath("html/body/div[3]/div/div/form/div[2]/div[2]/table/tbody/tr[10]/td/label/select")).sendKeys("Caviller");
	element(by.buttonText("NEXT >")).click();
	element(by.xpath("html/body/div[3]/div/div/form/div[2]/div/div/table[5]/tbody/tr[2]/td/label/input")).click();
	element(by.buttonText("CREATE")).click();
	
	
});

it("WATS with Disconnect", function() {
	
	element(by.xpath("html/body/div[3]/div/div/form/div[2]/div[2]/table/tbody/tr[6]/td[1]/label/input")).click();
	element(by.xpath("html/body/div[3]/div/div/form/div[2]/div[2]/table/tbody/tr[10]/td/label/select")).sendKeys("Caviller");
	element(by.buttonText("NEXT >")).click();
	element(by.xpath("html/body/div[3]/div/div/form/div[2]/div/div/table[5]/tbody/tr[3]/td/label/input")).click();
	element(by.buttonText("CREATE")).click();
	
});

it("WATS with Change", function() {
	
	element(by.xpath("html/body/div[3]/div/div/form/div[2]/div[2]/table/tbody/tr[6]/td[1]/label/input")).click();
	element(by.xpath("html/body/div[3]/div/div/form/div[2]/div[2]/table/tbody/tr[10]/td/label/select")).sendKeys("Caviller");
	element(by.buttonText("NEXT >")).click();
	element(by.xpath("html/body/div[3]/div/div/form/div[2]/div/div/table[5]/tbody/tr[4]/td/label/input")).click();
	element(by.buttonText("CREATE")).click();
	
});

it("WATS with Inside Move", function() {
	
	element(by.xpath("html/body/div[3]/div/div/form/div[2]/div[2]/table/tbody/tr[6]/td[1]/label/input")).click();
	element(by.xpath("html/body/div[3]/div/div/form/div[2]/div[2]/table/tbody/tr[10]/td/label/select")).sendKeys("Caviller");
	element(by.buttonText("NEXT >")).click();
	element(by.xpath("html/body/div[3]/div/div/form/div[2]/div/div/table[5]/tbody/tr[5]/td/label/input")).click();
	element(by.buttonText("CREATE")).click();
	
});

it("WATS with Outside Move", function() {
	
	element(by.xpath("html/body/div[3]/div/div/form/div[2]/div[2]/table/tbody/tr[6]/td[1]/label/input")).click();
	element(by.xpath("html/body/div[3]/div/div/form/div[2]/div[2]/table/tbody/tr[10]/td/label/select")).sendKeys("Caviller");
	element(by.buttonText("NEXT >")).click();
	element(by.xpath("html/body/div[3]/div/div/form/div[2]/div/div/table[5]/tbody/tr[6]/td/label/input")).click();
	element(by.buttonText("CREATE")).click();
	
});

it("WATS with Records", function() {
	
	element(by.xpath("html/body/div[3]/div/div/form/div[2]/div[2]/table/tbody/tr[6]/td[1]/label/input")).click();
	element(by.xpath("html/body/div[3]/div/div/form/div[2]/div[2]/table/tbody/tr[10]/td/label/select")).sendKeys("Caviller");
	element(by.buttonText("NEXT >")).click();
	element(by.xpath("html/body/div[3]/div/div/form/div[2]/div/div/table[5]/tbody/tr[7]/td/label/input")).click();
	element(by.buttonText("CREATE")).click();
	
});



it("PVC standalone with New", function() {
	
	element(by.xpath("html/body/div[3]/div/div/form/div[2]/div[2]/table/tbody/tr[6]/td[2]/label/input")).click();
	element(by.xpath("html/body/div[3]/div/div/form/div[2]/div[2]/table/tbody/tr[10]/td/label/select")).sendKeys("Caviller");
	element(by.buttonText("NEXT >")).click();
	element(by.xpath("html/body/div[3]/div/div/form/div[2]/div/div/table[5]/tbody/tr[2]/td/label/input")).click();
	element(by.buttonText("CREATE")).click();
	
});

it("PVC standalone with Disconnect", function() {
	
	element(by.xpath("html/body/div[3]/div/div/form/div[2]/div[2]/table/tbody/tr[6]/td[2]/label/input")).click();
	element(by.xpath("html/body/div[3]/div/div/form/div[2]/div[2]/table/tbody/tr[10]/td/label/select")).sendKeys("Caviller");
	element(by.buttonText("NEXT >")).click();
	element(by.xpath("html/body/div[3]/div/div/form/div[2]/div/div/table[5]/tbody/tr[3]/td/label/input")).click();
	element(by.buttonText("CREATE")).click();
	
});

it("PVC standalone with Change", function() {
	
	element(by.xpath("html/body/div[3]/div/div/form/div[2]/div[2]/table/tbody/tr[6]/td[2]/label/input")).click();
	element(by.xpath("html/body/div[3]/div/div/form/div[2]/div[2]/table/tbody/tr[10]/td/label/select")).sendKeys("Caviller");
	element(by.buttonText("NEXT >")).click();
	element(by.xpath("html/body/div[3]/div/div/form/div[2]/div/div/table[5]/tbody/tr[4]/td/label/input")).click();
	element(by.buttonText("CREATE")).click();
	
});

it("PVC standalone with Records", function() {
	
	element(by.xpath("html/body/div[3]/div/div/form/div[2]/div[2]/table/tbody/tr[6]/td[2]/label/input")).click();
	element(by.xpath("html/body/div[3]/div/div/form/div[2]/div[2]/table/tbody/tr[10]/td/label/select")).sendKeys("Caviller");
	element(by.buttonText("NEXT >")).click();
	element(by.xpath("html/body/div[3]/div/div/form/div[2]/div/div/table[5]/tbody/tr[7]/td/label/input")).click();
	element(by.buttonText("CREATE")).click();
	
});

it("Dedicated Internet Service with New", function() {
	
	element(by.xpath("html/body/div[3]/div/div/form/div[2]/div[2]/table/tbody/tr[7]/td[2]/label/input")).click();
	element(by.xpath("html/body/div[3]/div/div/form/div[2]/div[2]/table/tbody/tr[10]/td/label/select")).sendKeys("Caviller");
	element(by.buttonText("NEXT >")).click();
	element(by.xpath("html/body/div[3]/div/div/form/div[2]/div/div/table[5]/tbody/tr[2]/td/label/input")).click();
	element(by.buttonText("CREATE")).click();
	
});

it("Dedicated Internet Service with Disconnect", function() {
	
	element(by.xpath("html/body/div[3]/div/div/form/div[2]/div[2]/table/tbody/tr[7]/td[2]/label/input")).click();
	element(by.xpath("html/body/div[3]/div/div/form/div[2]/div[2]/table/tbody/tr[10]/td/label/select")).sendKeys("Caviller");
	element(by.buttonText("NEXT >")).click();
	element(by.xpath("html/body/div[3]/div/div/form/div[2]/div/div/table[5]/tbody/tr[3]/td/label/input")).click();
	element(by.buttonText("CREATE")).click();
	
});

it("Dedicated Internet Service with Change", function() {
	
	element(by.xpath("html/body/div[3]/div/div/form/div[2]/div[2]/table/tbody/tr[7]/td[2]/label/input")).click();
	element(by.xpath("html/body/div[3]/div/div/form/div[2]/div[2]/table/tbody/tr[10]/td/label/select")).sendKeys("Caviller");
	element(by.buttonText("NEXT >")).click();
	element(by.xpath("html/body/div[3]/div/div/form/div[2]/div/div/table[5]/tbody/tr[4]/td/label/input")).click();
	element(by.buttonText("CREATE")).click();
	
});

it("Dedicated Internet Service with Inside Move", function() {
	
	element(by.xpath("html/body/div[3]/div/div/form/div[2]/div[2]/table/tbody/tr[7]/td[2]/label/input")).click();
	element(by.xpath("html/body/div[3]/div/div/form/div[2]/div[2]/table/tbody/tr[10]/td/label/select")).sendKeys("Caviller");
	element(by.buttonText("NEXT >")).click();
	element(by.xpath("html/body/div[3]/div/div/form/div[2]/div/div/table[5]/tbody/tr[5]/td/label/input")).click();
	element(by.buttonText("CREATE")).click();
	
});

it("Dedicated Internet Service with Outside Move", function() {
	
	element(by.xpath("html/body/div[3]/div/div/form/div[2]/div[2]/table/tbody/tr[7]/td[2]/label/input")).click();
	element(by.xpath("html/body/div[3]/div/div/form/div[2]/div[2]/table/tbody/tr[10]/td/label/select")).sendKeys("Caviller");
	element(by.buttonText("NEXT >")).click();
	element(by.xpath("html/body/div[3]/div/div/form/div[2]/div/div/table[5]/tbody/tr[6]/td/label/input")).click();
	element(by.buttonText("CREATE")).click();
	
});

it("Dedicated Internet Service with Records", function() {
	
	element(by.xpath("html/body/div[3]/div/div/form/div[2]/div[2]/table/tbody/tr[7]/td[2]/label/input")).click();
	element(by.xpath("html/body/div[3]/div/div/form/div[2]/div[2]/table/tbody/tr[10]/td/label/select")).sendKeys("Caviller");
	element(by.buttonText("NEXT >")).click();
	element(by.xpath("html/body/div[3]/div/div/form/div[2]/div/div/table[5]/tbody/tr[7]/td/label/input")).click();
	element(by.buttonText("CREATE")).click();
	
});

it("Service Inquiry with New", function() {
	
	element(by.xpath("html/body/div[3]/div/div/form/div[2]/div[2]/table/tbody/tr[8]/td/label/input")).click();
	element(by.xpath("html/body/div[3]/div/div/form/div[2]/div[2]/table/tbody/tr[10]/td/label/select")).sendKeys("Caviller");
	element(by.buttonText("NEXT >")).click();
	element(by.xpath("html/body/div[3]/div/div/form/div[2]/div/div/table[5]/tbody/tr[2]/td/label/input")).click();
	element(by.buttonText("CREATE")).click();
	
});



it("Private Ip UNI with New", function() {
	
	element(by.xpath("html/body/div[3]/div/div/form/div[2]/div[2]/table/tbody/tr[7]/td[1]/label/input")).click();
	element(by.xpath("html/body/div[3]/div/div/form/div[2]/div[2]/table/tbody/tr[10]/td/label/select")).sendKeys("Caviller");
	element(by.buttonText("NEXT >")).click();
	element(by.xpath("html/body/div[3]/div/div/form/div[2]/div/div/table[1]/tbody/tr[2]/td/label/input")).click();
	element(by.xpath("html/body/div[3]/div/div/form/div[2]/div/div/table[5]/tbody/tr[2]/td/label/input")).click();
	element(by.buttonText("CREATE")).click();
	
});

it("Private Ip UNI with Disconnect", function() {
	
	element(by.xpath("html/body/div[3]/div/div/form/div[2]/div[2]/table/tbody/tr[7]/td[1]/label/input")).click();
	element(by.xpath("html/body/div[3]/div/div/form/div[2]/div[2]/table/tbody/tr[10]/td/label/select")).sendKeys("Caviller");
	element(by.buttonText("NEXT >")).click();
	element(by.xpath("html/body/div[3]/div/div/form/div[2]/div/div/table[1]/tbody/tr[2]/td/label/input")).click();
	element(by.xpath("html/body/div[3]/div/div/form/div[2]/div/div/table[5]/tbody/tr[3]/td/label/input")).click();
	element(by.buttonText("CREATE")).click();
	
});

it("Private Ip UNI with Change", function() {
	
	element(by.xpath("html/body/div[3]/div/div/form/div[2]/div[2]/table/tbody/tr[7]/td[1]/label/input")).click();
	element(by.xpath("html/body/div[3]/div/div/form/div[2]/div[2]/table/tbody/tr[10]/td/label/select")).sendKeys("Caviller");
	element(by.buttonText("NEXT >")).click();
	element(by.xpath("html/body/div[3]/div/div/form/div[2]/div/div/table[1]/tbody/tr[2]/td/label/input")).click();
	element(by.xpath("html/body/div[3]/div/div/form/div[2]/div/div/table[5]/tbody/tr[4]/td/label/input")).click();
	element(by.buttonText("CREATE")).click();
	
});

it("Private Ip UNI with Inside Move", function() {
	
	element(by.xpath("html/body/div[3]/div/div/form/div[2]/div[2]/table/tbody/tr[7]/td[1]/label/input")).click();
	element(by.xpath("html/body/div[3]/div/div/form/div[2]/div[2]/table/tbody/tr[10]/td/label/select")).sendKeys("Caviller");
	element(by.buttonText("NEXT >")).click();
	element(by.xpath("html/body/div[3]/div/div/form/div[2]/div/div/table[1]/tbody/tr[2]/td/label/input")).click();
	element(by.xpath("html/body/div[3]/div/div/form/div[2]/div/div/table[5]/tbody/tr[5]/td/label/input")).click();
	element(by.buttonText("CREATE")).click();
	
});

it("Private Ip UNI with Outside Move", function() {
	
	element(by.xpath("html/body/div[3]/div/div/form/div[2]/div[2]/table/tbody/tr[7]/td[1]/label/input")).click();
	element(by.xpath("html/body/div[3]/div/div/form/div[2]/div[2]/table/tbody/tr[10]/td/label/select")).sendKeys("Caviller");
	element(by.buttonText("NEXT >")).click();
	element(by.xpath("html/body/div[3]/div/div/form/div[2]/div/div/table[1]/tbody/tr[2]/td/label/input")).click();
	element(by.xpath("html/body/div[3]/div/div/form/div[2]/div/div/table[5]/tbody/tr[6]/td/label/input")).click();
	element(by.buttonText("CREATE")).click();
	
});

it("Private Ip UNI with Records", function() {
	
	element(by.xpath("html/body/div[3]/div/div/form/div[2]/div[2]/table/tbody/tr[7]/td[1]/label/input")).click();
	element(by.xpath("html/body/div[3]/div/div/form/div[2]/div[2]/table/tbody/tr[10]/td/label/select")).sendKeys("Caviller");
	element(by.buttonText("NEXT >")).click();
	element(by.xpath("html/body/div[3]/div/div/form/div[2]/div/div/table[1]/tbody/tr[2]/td/label/input")).click();
	element(by.xpath("html/body/div[3]/div/div/form/div[2]/div/div/table[5]/tbody/tr[7]/td/label/input")).click();
	element(by.buttonText("CREATE")).click();
	
});

it("Private Ip EVC with NEW", function() {
	
	element(by.xpath("html/body/div[3]/div/div/form/div[2]/div[2]/table/tbody/tr[7]/td[1]/label/input")).click();
	element(by.xpath("html/body/div[3]/div/div/form/div[2]/div[2]/table/tbody/tr[10]/td/label/select")).sendKeys("Caviller");
	element(by.buttonText("NEXT >")).click();
	element(by.xpath("html/body/div[3]/div/div/form/div[2]/div/div/table[1]/tbody/tr[3]/td/label/input")).click();
	element(by.xpath("html/body/div[3]/div/div/form/div[2]/div/div/table[5]/tbody/tr[2]/td/label/input")).click();
	element(by.buttonText("CREATE")).click();
	
});

it("Private Ip EVC with Disconnect", function() {
	
	element(by.xpath("html/body/div[3]/div/div/form/div[2]/div[2]/table/tbody/tr[7]/td[1]/label/input")).click();
	element(by.xpath("html/body/div[3]/div/div/form/div[2]/div[2]/table/tbody/tr[10]/td/label/select")).sendKeys("Caviller");
	element(by.buttonText("NEXT >")).click();
	element(by.xpath("html/body/div[3]/div/div/form/div[2]/div/div/table[1]/tbody/tr[3]/td/label/input")).click();
	element(by.xpath("html/body/div[3]/div/div/form/div[2]/div/div/table[5]/tbody/tr[3]/td/label/input")).click();
	element(by.buttonText("CREATE")).click();
	
});

it("Private Ip EVC with Records", function() {
	
	element(by.xpath("html/body/div[3]/div/div/form/div[2]/div[2]/table/tbody/tr[7]/td[1]/label/input")).click();
	element(by.xpath("html/body/div[3]/div/div/form/div[2]/div[2]/table/tbody/tr[10]/td/label/select")).sendKeys("Caviller");
	element(by.buttonText("NEXT >")).click();
	element(by.xpath("html/body/div[3]/div/div/form/div[2]/div/div/table[1]/tbody/tr[3]/td/label/input")).click();
	element(by.xpath("html/body/div[3]/div/div/form/div[2]/div/div/table[5]/tbody/tr[7]/td/label/input")).click();
	element(by.buttonText("CREATE")).click();
	
});

it("Private Ip PVC with New", function() {
	
	element(by.xpath("html/body/div[3]/div/div/form/div[2]/div[2]/table/tbody/tr[7]/td[1]/label/input")).click();
	element(by.xpath("html/body/div[3]/div/div/form/div[2]/div[2]/table/tbody/tr[10]/td/label/select")).sendKeys("Caviller");
	element(by.buttonText("NEXT >")).click();
	element(by.xpath("html/body/div[3]/div/div/form/div[2]/div/div/table[1]/tbody/tr[4]/td/label/input")).click();
	element(by.xpath("html/body/div[3]/div/div/form/div[2]/div/div/table[5]/tbody/tr[2]/td/label/input")).click();
	element(by.buttonText("CREATE")).click();
	
});

it("Private Ip PVC with Disconnect", function() {
	
	element(by.xpath("html/body/div[3]/div/div/form/div[2]/div[2]/table/tbody/tr[7]/td[1]/label/input")).click();
	element(by.xpath("html/body/div[3]/div/div/form/div[2]/div[2]/table/tbody/tr[10]/td/label/select")).sendKeys("Caviller");
	element(by.buttonText("NEXT >")).click();
	element(by.xpath("html/body/div[3]/div/div/form/div[2]/div/div/table[1]/tbody/tr[4]/td/label/input")).click();
	element(by.xpath("html/body/div[3]/div/div/form/div[2]/div/div/table[5]/tbody/tr[3]/td/label/input")).click();
	element(by.buttonText("CREATE")).click();
	
});

it("Private Ip PVC with Records", function() {
	
	element(by.xpath("html/body/div[3]/div/div/form/div[2]/div[2]/table/tbody/tr[7]/td[1]/label/input")).click();
	element(by.xpath("html/body/div[3]/div/div/form/div[2]/div[2]/table/tbody/tr[10]/td/label/select")).sendKeys("Caviller");
	element(by.buttonText("NEXT >")).click();
	element(by.xpath("html/body/div[3]/div/div/form/div[2]/div/div/table[1]/tbody/tr[4]/td/label/input")).click();
	element(by.xpath("html/body/div[3]/div/div/form/div[2]/div/div/table[5]/tbody/tr[7]/td/label/input")).click();
	element(by.buttonText("CREATE")).click();
	
});

it("ASR SEND PRE_ORDER WITH ADDRESS VALIDATION INQUIRY, Query by address", function() {
	
	element(by.xpath("html/body/div[3]/div/div/form/div[2]/div[1]/table/tbody/tr[2]/td[2]/label/input")).click();
	element(by.xpath("html/body/div[3]/div/div/form/div[2]/div[3]/table/tbody/tr[2]/td/label/input")).click();
	element(by.xpath("html/body/div[3]/div/div/form/div[2]/div[3]/table/tbody/tr[6]/td/label/select")).sendKeys("QWEST");
	element(by.buttonText("NEXT >")).click();
	element(by.xpath("html/body/div[3]/div/div/form/div[2]/table/tbody/tr[3]/td/label/input")).click();
	element(by.buttonText("CREATE")).click();
});

it("ASR SEND PRE_ORDER WITH ADDRESS VALIDATION INQUIRY, Query by Working telephone number ", function() {
	
	element(by.xpath("html/body/div[3]/div/div/form/div[2]/div[1]/table/tbody/tr[2]/td[2]/label/input")).click();
	element(by.xpath("html/body/div[3]/div/div/form/div[2]/div[3]/table/tbody/tr[2]/td/label/input")).click();
	element(by.xpath("html/body/div[3]/div/div/form/div[2]/div[3]/table/tbody/tr[6]/td/label/select")).sendKeys("QWEST");
	element(by.buttonText("NEXT >")).click();
	element(by.xpath("html/body/div[3]/div/div/form/div[2]/table/tbody/tr[4]/td/label/input")).click();
	element(by.buttonText("CREATE")).click();
});

it("ASR SEND PRE_ORDER WITH ADDRESS VALIDATION INQUIRY, Query by Working circuit ", function() {
	
	element(by.xpath("html/body/div[3]/div/div/form/div[2]/div[1]/table/tbody/tr[2]/td[2]/label/input")).click();
	element(by.xpath("html/body/div[3]/div/div/form/div[2]/div[3]/table/tbody/tr[2]/td/label/input")).click();
	element(by.xpath("html/body/div[3]/div/div/form/div[2]/div[3]/table/tbody/tr[6]/td/label/select")).sendKeys("QWEST");
	element(by.buttonText("NEXT >")).click();
	element(by.xpath("html/body/div[3]/div/div/form/div[2]/table/tbody/tr[5]/td/label/input")).click();
	element(by.buttonText("CREATE")).click();
});

it("ASR SEND PRE_ORDER WITH SERVICE AVAILABILITY INQUIRY", function() {
	
	element(by.xpath("html/body/div[3]/div/div/form/div[2]/div[1]/table/tbody/tr[2]/td[2]/label/input")).click();
	element(by.xpath("html/body/div[3]/div/div/form/div[2]/div[3]/table/tbody/tr[3]/td/label/input")).click();
	element(by.xpath("html/body/div[3]/div/div/form/div[2]/div[3]/table/tbody/tr[6]/td/label/select")).sendKeys("AT&T");
	element(by.buttonText("CREATE")).click();
	
});

it("ASR SEND PRE_ORDER WITH CFA VALIDATION INQUIRY", function() {
	
	element(by.xpath("html/body/div[3]/div/div/form/div[2]/div[1]/table/tbody/tr[2]/td[2]/label/input")).click();
	element(by.xpath("html/body/div[3]/div/div/form/div[2]/div[3]/table/tbody/tr[4]/td/label/input")).click();
	element(by.xpath("html/body/div[3]/div/div/form/div[2]/div[3]/table/tbody/tr[6]/td/label/select")).sendKeys("QWEST");
	element(by.buttonText("CREATE")).click();
	
});

it("ASR NON BONDED RESPONSE WITH CLARIFICATION", function() {
	
	element(by.xpath("html/body/div[3]/div/div/form/div[2]/div[1]/table/tbody/tr[3]/td/label/input")).click();
	element(by.xpath("html/body/div[3]/div/div/form/div[2]/div[4]/table/tbody/tr[2]/td/label/input")).click();
	element(by.xpath("html/body/div[3]/div/div/form/div[2]/div[4]/table/tbody/tr[7]/td/label/select")).sendKeys("QWEST");
	element(by.buttonText("CREATE")).click();
	
});

it("ASR NON BONDED RESPONSE WITH CONFIRMATION", function() {
	
	element(by.xpath("html/body/div[3]/div/div/form/div[2]/div[1]/table/tbody/tr[3]/td/label/input")).click();
	element(by.xpath("html/body/div[3]/div/div/form/div[2]/div[4]/table/tbody/tr[3]/td/label/input")).click();
	element(by.xpath("html/body/div[3]/div/div/form/div[2]/div[4]/table/tbody/tr[7]/td/label/select")).sendKeys("QWEST");
	element(by.buttonText("CREATE")).click();
	
});

it("ASR NON BONDED RESPONSE WITH DLR", function() {
	
	element(by.xpath("html/body/div[3]/div/div/form/div[2]/div[1]/table/tbody/tr[3]/td/label/input")).click();
	element(by.xpath("html/body/div[3]/div/div/form/div[2]/div[4]/table/tbody/tr[4]/td/label/input")).click();
	element(by.xpath("html/body/div[3]/div/div/form/div[2]/div[4]/table/tbody/tr[7]/td/label/select")).sendKeys("QWEST");
	element(by.buttonText("CREATE")).click();
	
});

it("ASR NON BONDED RESPONSE WITH SEC CONFIRMATION", function() {
	
	element(by.xpath("html/body/div[3]/div/div/form/div[2]/div[1]/table/tbody/tr[3]/td/label/input")).click();
	element(by.xpath("html/body/div[3]/div/div/form/div[2]/div[4]/table/tbody/tr[5]/td/label/input")).click();
	element(by.xpath("html/body/div[3]/div/div/form/div[2]/div[4]/table/tbody/tr[7]/td/label/select")).sendKeys("QWEST");
	browser.sleep("3000");
	element(by.buttonText("CREATE")).click();
	
});

	
});